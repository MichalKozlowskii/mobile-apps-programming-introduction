package com.example.recyclerviewbasics;

public interface OnItemClickListener {
    void onItemClick(int position);
}
